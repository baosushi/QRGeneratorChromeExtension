chrome.runtime.onInstalled.addListener(function() {
	console.log("ayyyyyyyyy");
});